<?php
/**
 *
 Plugin Name: Ultimate Addons Elementor
 Plugin URI:  https://developer.wordpress.org/plugins/the-basics/
 Description: Ultimate Addons for Elementor
 Version:     1.0.0
 Author:      Sushma Kure
 Author URI:  https://codepen.io/sushmak02
 Text Domain: uae
 Domain Path: /languages
 */

require_once 'classes/class-uae-loader.php';

echo ' welcome';